## v0.5.2 - Alpha 1
- Refactored code into a more data oriented design
- Balance changes

## v0.5.1
- Small fixes

## v0.5
- Added stats
- Added achievements 
- CSS backend changes / organization
- Fixed watcher.js backend
- Added offline earnings modal

## v0.4.1
- Stylistic changes / cool things
- Squashed web_mono_lib bugs
- Switched out prestige upgrade for "magic orbs"
- Better cash per second text

## v0.4
- Changed theme to "dark"
- Added new menu section and canvas moving system
- Added working settings for drawing entities
- Squashed bugs (with prestige mostly)
- Styled it up
- Had fun

## v0.3.2
- Scaled graphics
- Optimized trig
- Reorganized code

## v0.3.1
- Balancing changes to prestige

## v0.3
- Bug squashing
- Added custom dev console
- Added more upgrades to idle section

## v0.2
- Optimized the shiz outa the physics/rendering engine
- More balance changes to orb values.

## v0.1
- Added prestige functionality and prestige upgrades that work.

## initial commit
- The basic bs of an initial commit
- Orb upgrades
- Idle upgrade
- Prestige kinda being set, but not really.