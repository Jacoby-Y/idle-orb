## A satisfying game about physics and multipliers


Pages link: https://jacoby-y.github.io/idle-orb/


## Todo / Ideas
- ...


## Optimization Stats (% spent)
- Drawing function
    - Draw Circle: 24.8%;
    - Draw Polygon: 21.5% (10 sides)
    - Draw Polygon: 20% (6 sides)
    - Draw Rect: 8%

    - Draw Polygon: 22.4% (6 sides)
    - Draw Decagon: 24%

    - Draw Rect: 4.5% - 4.2%
    - Draw Decagon: 13.5% - 19%